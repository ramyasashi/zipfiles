import { Component } from '@angular/core';
// import * as am4core from "@amcharts/amcharts4/core";
// import * as am4charts from "@amcharts/amcharts4/charts";
// ... other imports
// import am4themes_animated from "@amcharts/amcharts4/themes/animated";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'zoomableRadarChart';
  // am4core.useTheme(am4themes_animated);
  public demoradarChartLabels:string[] = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n'];
 
  public demoradarChartData:any = [
    {data: [0,10,10], label: 'Company A'},
    {data: [0,20,20], label: 'Company B'},
    {data: [0,0,30,30], label: 'Company C'},
    {data: [0,0,0,87,87], label: 'Company D'},
    {data: [0,0,0,0,45,45], label: 'Company E'},
    {data: [0,0,0,0,0,30,30], label: 'Company F'},
    {data: [0,0,0,0,0,0,20,20], label: 'Company G'},
    {data: [0,0,0,0,0,0,0,60,60], label: 'Company H'},
    {data: [0,0,0,0,0,0,0,0,40,40], label: 'Company I'},
    {data: [0,0,0,0,0,0,0,0,0,55,55], label: 'Company J'},
    {data: [0,0,0,0,0,0,0,0,0,0,30,30], label: 'Company K'},
    {data: [0,0,0,0,0,0,0,0,0,0,0,93,93], label: 'Company L'},
    {data: [0,0,0,0,0,0,0,0,0,0,0,0,52,52], label: 'Company M'},
    {data: [0,0,0,0,0,0,0,0,0,0,0,0,0,35,35], label: 'Company N'}
  ];
  public radarChartType:string = 'radar';
 
  // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }
}

