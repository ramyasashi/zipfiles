import { User } from './user';

export class UserDetails{
    id: number;
    fvFood: string;
    fvMovie: string;
    familySize: number;
}