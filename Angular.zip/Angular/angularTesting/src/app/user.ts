export class User {
    id: number;
    name: string;
    age: number;
}
