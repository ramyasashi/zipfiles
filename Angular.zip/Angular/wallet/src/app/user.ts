export class User {
    amount: number;
    name: string;
    accountNumber: number;
    ifscCode: string;
    date: string
}