export class AccountUser {
    email: string;
    password: string;
}