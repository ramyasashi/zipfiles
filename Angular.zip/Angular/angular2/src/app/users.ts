export class Users{
    name: string;
    state: string;
    time: string;
    location: {
        latitude: number;
        longitude: number;
    }
    alertMessage: string;
}