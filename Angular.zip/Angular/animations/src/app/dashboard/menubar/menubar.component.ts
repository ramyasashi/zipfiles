import { Component, OnInit, Input } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { Role } from 'src/app/models/role';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.scss']
})
export class MenubarComponent implements OnInit {

  // isUser:boolean = false;
 
  currentUser: User;
  constructor(public route: ActivatedRoute, private authService: AuthService, private router: Router) { }

  ngOnInit() {
    this.route.queryParams.subscribe(v => console.log(v));
  }
  // get isUser() {
  //   return this.currentUser && this.currentUser.role === Role.Admin;
  // }
  get isAdmin() {
    return this.currentUser && this.currentUser.role === Role.Admin;
  }
  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
}

}
