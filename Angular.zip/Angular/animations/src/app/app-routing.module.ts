import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './dashboard/home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LoginComponent } from './auth/login/login.component';
import { AuthGuard } from './auth/auth.guard';
import { Role } from './models/role';


const routes: Routes = [
  // {
  //   path:'',
  //   redirectTo:'home',
  //   pathMatch: 'full'
  // },
  // {
  //   path:'',
  //   component: HomeComponent,
  //   data : {isUser : true},
  //   children: [
  //     {
  //       path:'login',
  //       component:LoginComponent
  //     }
  //   ]
  // },
  
  // {
  //   path:'**',
  //   component: PageNotFoundComponent
  // }
  {
    path: '',
    component: HomeComponent,
    canActivate: [AuthGuard]
},
{ 
    path: 'admin', 
    component: HomeComponent, 
    canActivate: [AuthGuard], 
    data: { roles: [Role.Admin] } 
},
{ 
    path: 'login', 
    component: LoginComponent 
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
