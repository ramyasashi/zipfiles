export enum Role {
  User = 'User',
  Admin = 'Admin'
}