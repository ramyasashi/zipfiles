export interface Logs {
  userId: number;
  logStatus: boolean;
}
